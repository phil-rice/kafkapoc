# test-data


python in-out.py --parcels 100 --output-dir out --batch-size 200

python in-out.py --parcels 2500000 --output-dir ./rm_pairs --batch-size 100000 --seed 123


python generate_rm_full_dataset.py --parcels 100 --output-dir out --batch-size 200 --seed 42


python generate_rm_full_dataset.py --parcels 2500000 --output-dir ./rm_dataset --batch-size 100000 --seed 123
